__app_name__ = "YAMP"
__title__ = "YAMP"
__sub_title__ = "Yet Another Music Player"
__description__ = "An online music player that no one asked for."

__version__ = "v0.1.0"

__author__ = "Nur Alam"
